

function partyModeActivator(mode) {
    const divs = document.querySelector('div');
    const imgs = document.querySelector('img');
    const p = document.querySelector('p');
    const body = document.querySelector('body');

    switch (mode) {
        case "Party Mode 1":
        return divs.addClass("mode1");
        case "Party Mode 2":
        return imgs.addClass("mode2");
        case "Party Mode 3":
        return p.addClass("mode3");
        case "Party Mode 4":
        return body.addClass("mode4");
    }
}

document.addEventListener('click', (e) => {
    if (e.target.class(party)) {
       var mode = e.target.textContent;
       //var modee = e.target.id;
       partyModeActivator(mode);
    }
})